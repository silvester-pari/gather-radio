module.exports = {
  ROOM_ID: 'WRRmUQRrCm4nLslm\\eox-office',
  MAP_ID: 'eox-office-backup',
  API_KEY: 'snoQYKPUEiuSLsFR',
  DOOR_IMAGES: {
    open: 'https://cdn.gather.town/v0/b/gather-town-dev.appspot.com/o/objects%2Fblank.png?alt=media&token=6564fd34-433a-4e08-843a-5c4b50d6f9e5',
    closed: 'https://cdn.gather.town/v0/b/gather-town.appspot.com/o/uploads%2FWRRmUQRrCm4nLslm%2Fassets%2Fefc31368-ee12-4729-9115-d35bc89ead84?alt=media&token=3b419b4e-e0ab-43a6-ae24-510c03d4fd42',
    closed_highlight: 'https://cdn.gather.town/v0/b/gather-town.appspot.com/o/uploads%2FWRRmUQRrCm4nLslm%2Fassets%2F9c0fd47c-41eb-48b5-832a-47d528abb9b8?alt=media&token=a711a162-76ed-430a-b916-782ce7844509',
  },
  DOOR_POS: {
    x: 30,
    y: 8
  },
  PASSWORD: '12345',
};
