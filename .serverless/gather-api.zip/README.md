# Gather API tests

Based on https://github.com/serverless/examples/tree/master/aws-node-simple-http-endpoint

## Setup

```bash
npm install -g serverless
```

## Invoke the function locally

```bash
serverless invoke local --function currentTime
```

## Deploy

In order to deploy the endpoint, simply run:

```bash
serverless deploy
```
For the frontend in `client/dist` (uploaded to S3), run:
```bash
serverless client deploy
```